package com.skycast.weatherservice.constants;

public final class ApplicationDefaultConstants {

    public static final String RESPONSE_STATUS_200 = "200";

    public static final String RESPONSE_MESSAGE_200 = "Request processed successfully";

    private ApplicationDefaultConstants(){
    }
}
